import { GoogleGenAI, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

type ImageInput = { data: string; mimeType: string };

export const generateImage = async (
    prompt: string,
    modelImage?: ImageInput,
    fabricImage?: ImageInput
): Promise<string> => {
    try {
        if (modelImage || fabricImage) {
            console.log("Generating with multimodal inputs...");
            const parts: any[] = [];
            
            let instruction = "Please generate a new, high-quality photograph based on the following inputs.";

            if (modelImage) {
                instruction += " Use the person from the first provided image as the model.";
                parts.push({ inlineData: { data: modelImage.data, mimeType: modelImage.mimeType } });
            }

            if (fabricImage) {
                const fabricInstruction = modelImage 
                    ? " Apply the texture and pattern from the second provided image to the model's clothing." 
                    : " Create an outfit using the texture and pattern from the provided fabric image.";
                instruction += fabricInstruction;
                parts.push({ inlineData: { data: fabricImage.data, mimeType: fabricImage.mimeType } });
            }

            const finalPrompt = `${instruction} The overall scene and style should follow this description: "${prompt}"`;
            parts.push({ text: finalPrompt });

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts: parts },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });

            const firstPart = response.candidates?.[0]?.content?.parts?.[0];
            if (firstPart && firstPart.inlineData) {
                return firstPart.inlineData.data;
            }
            throw new Error("No image data received from Gemini API for multimodal request.");

        } else {
            console.log("Generating image with prompt only:", prompt);
            const response = await ai.models.generateImages({
                model: 'imagen-4.0-generate-001',
                prompt: prompt,
                config: {
                    numberOfImages: 1,
                    outputMimeType: 'image/jpeg',
                    aspectRatio: '3:4',
                },
            });

            const image = response.generatedImages?.[0]?.image;
            if (image && image.imageBytes) {
                return image.imageBytes;
            }
            throw new Error("No image data received from Imagen API.");
        }
    } catch (error) {
        console.error("Error generating image with Gemini API:", error);
        if (error instanceof Error) {
            throw new Error(`Gemini API Error: ${error.message}`);
        }
        throw new Error("An unknown error occurred while generating the image.");
    }
};

export const changeDressColor = async (
    base64Image: string,
    mimeType: string,
    color: string
): Promise<string> => {
    try {
        console.log(`Changing dress color to ${color}...`);
        const prompt = `Taking this image as a reference, change the color of the main outfit worn by the person to ${color}. Ensure the rest of the image, including the background, skin tones, and other details, remains unchanged. The new color should look natural on the fabric.`;
        
        const imagePart = {
            inlineData: {
                data: base64Image,
                mimeType: mimeType,
            },
        };
        const textPart = { text: prompt };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        const firstPart = response.candidates?.[0]?.content?.parts?.[0];
        if (firstPart && firstPart.inlineData) {
            return firstPart.inlineData.data;
        }
        
        throw new Error("No image data received from Gemini API for color change request.");

    } catch (error) {
        console.error("Error changing dress color with Gemini API:", error);
        if (error instanceof Error) {
            throw new Error(`Gemini API Error: ${error.message}`);
        }
        throw new Error("An unknown error occurred while changing the dress color.");
    }
};