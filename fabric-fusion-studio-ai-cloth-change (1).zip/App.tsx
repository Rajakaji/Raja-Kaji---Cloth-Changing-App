import React, { useState, useCallback } from 'react';
import { generateImage, changeDressColor } from './services/geminiService';
import { ImagePlaceholder } from './components/ImagePlaceholder';
import { Spinner } from './components/Spinner';

const App: React.FC = () => {
    const initialPrompt = "A high-fashion photograph of a model wearing a stunning, custom outfit. The lighting should be dramatic, highlighting the texture of the fabric.";
    const [prompt, setPrompt] = useState<string>(initialPrompt);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isEditing, setIsEditing] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [modelImage, setModelImage] = useState<{ data: string; mimeType: string } | null>(null);
    const [fabricImage, setFabricImage] = useState<{ data: string; mimeType: string } | null>(null);

    const dressColors = ['Red', 'Blue', 'Emerald Green', 'Sunny Yellow', 'Royal Purple'];

    const handleImageChange = (
        event: React.ChangeEvent<HTMLInputElement>,
        setter: React.Dispatch<React.SetStateAction<{ data: string; mimeType: string; } | null>>
    ) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = (reader.result as string).split(',')[1];
                setter({ data: base64String, mimeType: file.type });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleGenerateImage = useCallback(async () => {
        if (!prompt || isLoading) return;

        setIsLoading(true);
        setError(null);
        setImageUrl(null);

        try {
            const base64Image = await generateImage(prompt, modelImage ?? undefined, fabricImage ?? undefined);
            setImageUrl(`data:image/png;base64,${base64Image}`);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to generate image. ${errorMessage}`);
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [prompt, isLoading, modelImage, fabricImage]);

    const handleColorChange = useCallback(async (color: string) => {
        if (!imageUrl || isEditing) return;

        setIsEditing(true);
        setError(null);

        try {
            const [header, base64Data] = imageUrl.split(',');
            const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';

            const newBase64Image = await changeDressColor(base64Data, mimeType, color);
            setImageUrl(`data:image/png;base64,${newBase64Image}`);

        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to change color. ${errorMessage}`);
            console.error(err);
        } finally {
            setIsEditing(false);
        }
    }, [imageUrl, isEditing]);

    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center p-4 sm:p-6 lg:p-8 font-sans">
            <div className="w-full max-w-7xl mx-auto">
                <header className="text-center mb-8">
                    <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
                        Fabric Fusion Studio AI
                    </h1>
                    <p className="text-gray-400 mt-2 text-lg">Bring your fashion concepts to life.</p>
                </header>

                <main className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                    {/* Column 1: Controls */}
                    <div className="lg:col-span-1 flex flex-col gap-8">
                        {/* 1. Prompt Section */}
                        <div className="w-full bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
                            <h2 className="text-2xl font-semibold mb-4 text-gray-200">1. Describe Your Vision</h2>
                            <textarea
                                id="prompt-input"
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="e.g., A woman in a silk saree on a rainy street..."
                                className="w-full h-40 p-3 bg-gray-900 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200 resize-none text-gray-300"
                            />
                        </div>
                        {/* 2. Model Picture Section */}
                        <div className="w-full bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
                             <h2 className="text-2xl font-semibold mb-4 text-gray-200">2. Upload Model (Optional)</h2>
                             <label htmlFor="model-upload" className="w-full cursor-pointer bg-gray-700 hover:bg-gray-600 text-gray-300 font-bold py-2 px-4 rounded-lg inline-flex items-center justify-center transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path d="M5.5 5.5A2.5 2.5 0 018 3h4a2.5 2.5 0 012.5 2.5v2.879a2.5 2.5 0 01-.732 1.767l-2.086 2.086a.5.5 0 00.707.707l2.086-2.086A3.5 3.5 0 0016 8.379V5.5A3.5 3.5 0 0012.5 2h-5A3.5 3.5 0 004 5.5v8A3.5 3.5 0 007.5 17h5a3.5 3.5 0 003.5-3.5v-2.879a3.5 3.5 0 00-1.025-2.475l-2.086-2.086a.5.5 0 00-.707.707l2.086 2.086A2.5 2.5 0 0115 10.621V13.5a2.5 2.5 0 01-2.5 2.5h-5a2.5 2.5 0 01-2.5-2.5v-8z"/></svg>
                                <span>Upload Model Picture</span>
                             </label>
                             <input id="model-upload" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageChange(e, setModelImage)} />
                             {modelImage && <img src={`data:${modelImage.mimeType};base64,${modelImage.data}`} alt="Model Reference" className="mt-4 w-full rounded-lg shadow-md" />}
                        </div>
                         {/* 3. Fabric Reference Section */}
                         <div className="w-full bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
                             <h2 className="text-2xl font-semibold mb-4 text-gray-200">3. Add Fabric (Optional)</h2>
                             <label htmlFor="fabric-upload" className="w-full cursor-pointer bg-gray-700 hover:bg-gray-600 text-gray-300 font-bold py-2 px-4 rounded-lg inline-flex items-center justify-center transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" /></svg>
                                <span>Upload Fabric Image</span>
                             </label>
                             <input id="fabric-upload" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageChange(e, setFabricImage)} />
                              {fabricImage && <img src={`data:${fabricImage.mimeType};base64,${fabricImage.data}`} alt="Fabric Reference" className="mt-4 w-full rounded-lg shadow-md" />}
                        </div>
                        <button
                            onClick={handleGenerateImage}
                            disabled={isLoading || !prompt}
                            className="w-full py-3 px-4 flex items-center justify-center font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg"
                        >
                            {isLoading ? <><Spinner />Generating...</> : 'Generate Image'}
                        </button>
                    </div>

                    {/* Image Display */}
                    <div className="lg:col-span-4 flex flex-col bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
                         <h2 className="text-2xl font-semibold mb-4 text-gray-200 text-center">Your Generated Image</h2>
                         <div className="flex-grow flex items-center justify-center bg-gray-900/50 rounded-lg min-h-[400px] lg:min-h-0 relative">
                            {(isLoading || isEditing) && (
                               <div className="absolute inset-0 bg-gray-900/70 flex flex-col items-center justify-center text-gray-400 z-10 rounded-lg">
                                   <Spinner />
                                   <p className="mt-4 text-lg animate-pulse">
                                       {isLoading ? "Weaving pixels into art..." : `Applying ${isEditing ? 'new color' : ''}...`}
                                   </p>
                               </div>
                            )}
                            {error && (
                                <div className="text-center text-red-400 p-4">
                                    <p className="font-semibold">Generation Failed</p>
                                    <p className="text-sm mt-2">{error}</p>
                                </div>
                            )}
                            {!isLoading && !error && !imageUrl && <ImagePlaceholder />}
                            {imageUrl && (
                                <div className="w-full h-full p-2">
                                    <img
                                        src={imageUrl}
                                        alt="Generated fashion concept"
                                        className={`object-contain w-full h-full max-h-[85vh] rounded-lg shadow-2xl transition-opacity duration-300 ${isEditing ? 'opacity-50' : 'opacity-100'}`}
                                    />
                                </div>
                            )}
                        </div>
                        {imageUrl && !isLoading && (
                             <div className="mt-6">
                                <p className="text-center text-gray-400 mb-3 font-semibold">Which color suits the mood?</p>
                                <div className="flex flex-wrap justify-center gap-3">
                                    {dressColors.map(color => (
                                        <button 
                                            key={color} 
                                            onClick={() => handleColorChange(color)}
                                            disabled={isEditing}
                                            className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500"
                                        >
                                            {color}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default App;